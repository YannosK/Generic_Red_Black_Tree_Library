#include "Evretirio.h"

#include "RedBlack.h" /* h Ylopoihsh sas toy R/B */
#else



struct EvrNode{
       TStoixeiouEvr *DataArray; /* array of size MaxSize */
       int Index;              /* index of first available element in array */
       typos_deikti TreeRoot;     /* Root of DDA */
} EvrNode;

EvrPtr EvrConstruct(int MaxSize){


}

int Evr_Insert(EvrPtr E, TStoixeiouEvr Data){ }

int EvrSearch(EvrPtr E, keyType key, int InOut, int * found){ }


int Evr_PrintAll(EvrPtr E, FILE *out, int * counter){

}

int Evr_katastrofi(EvrPtr *E){}
